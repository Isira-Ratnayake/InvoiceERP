<?php

class Customer {
    private $id;
    private $title;
    private $first_name;
    private $middle_name;
    private $last_name;
    private $contact_no;
    private $district;

    public function __construct($id, $title, $first_name, $middle_name, $last_name, $contact_no, $district) {
        $this->id = $id;
        $this->title = $title;
        $this->first_name = $first_name;
        $this->middle_name = $middle_name;
        $this->last_name = $last_name;
        $this->contact_no = $contact_no;
        $this->district = $district;
    }

    public function get_id() {
        return $this->id;
    }
    public function get_title() {
        return $this->title;
    }
    public function get_first_name() {
        return $this->first_name;
    }
    public function get_middle_name() {
        return $this->middle_name;
    }
    public function get_last_name() {
        return $this->last_name;
    }
    public function get_contact_no() {
        return $this->contact_no;
    }
    public function get_district() {
        return $this->district;
    }

    public function set_id($id) {
        $this->id = $id;
    }
    public function set_title($title) {
        $this->title = $title;
    }
    public function set_first_name($first_name) {
        $this->first_name = $first_name;
    }
    public function set_middle_name($middle_name) {
        $this->middle_name = $middle_name;
    }
    public function set_last_name($last_name) {
        $this->last_name = $last_name;
    }
    public function set_contact_no($contact_no) {
        $this->contact_no = $contact_no;
    }
    public function set_district($district) {
        $this->district = $district;
    }    
}

?>
