<?php

class Item {
    private $id;
    private $item_code;
    private $item_category;
    private $item_subcategory;
    private $item_name;
    private $quantity;
    private $unit_price;

    public function __construct($id, $item_code, $item_category, $item_subcategory, $item_name, $quantity, $unit_price) {
        $this->id = $id;
        $this->item_code = $item_code;
        $this->item_category = $item_category;
        $this->item_subcategory = $item_subcategory;
        $this->item_name = $item_name;
        $this->quantity = $quantity;
        $this->unit_price = $unit_price;
    }

    // Getters
    public function get_id() {
        return $this->id;
    }
    public function get_item_code() {
        return $this->item_code;
    }
    public function get_item_category() {
        return $this->item_category;
    }
    public function get_item_subcategory() {
        return $this->item_subcategory;
    }
    public function get_item_name() {
        return $this->item_name;
    }
    public function get_quantity() {
        return $this->quantity;
    }
    public function get_unit_price() {
        return $this->unit_price;
    }

    // Setters

    public function set_id($id) {
        $this->id = $id;
    }
    public function set_item_code($item_code) {
        $this->item_code = $item_code;
    }
    public function set_item_category($item_category) {
        $this->item_category = $item_category;
    }
    public function set_item_subcategory($item_subcategory) {
        $this->item_subcategory = $item_subcategory;
    }
    public function set_item_name($item_name) {
        $this->item_name = $item_name;
    }
    public function set_quantity($quantity) {
        $this->quantity = $quantity;
    }
    public function set_unit_price($unit_price) {
        $this->unit_price = $unit_price;
    }
}


?>