<div class="container mt-5">
    <div class="row">
        <div class="col">
            <div class="h1 text-center"><?php echo $heading?></div>
        </div>
    </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form action="./index.php?action=handle_cm_register" method="POST">
      <div class="h3 text-center">Register Customer</div>
        <div class="form-group">
          <label for="title">Title:</label>
            <select class="form-select" aria-label="Select Title" id="title" name="title" required>
                <option value="Mr">Mr</option>
                <option value="Mrs">Mrs</option>
                <option value="Miss">Miss</option>
                <option value="Dr">Dr</option>
            </select>
        </div>
        <div class="form-group">
          <label for="fname">First Name:</label>
          <input type="text" class="form-control" id="fname" name="fname" required>
        </div>
        <div class="form-group">
          <label for="mname">Middle Name:</label>
          <input type="text" class="form-control" id="mname" name="mname" required>
        </div>
        <div class="form-group">
          <label for="lname">Last Name:</label>
          <input type="text" class="form-control" id="lname" name="lname" required>
        </div>
        <div class="form-group">
          <label for="cno">Contact Number:</label>
          <input type="tel" pattern="[0-9]{10}" placeholder="0XXXXXXXXX" class="form-control" id="cno" name="cno" required>
        </div>
        <div class="form-group">
          <label for="district">District:</label>
          <select class="form-select" aria-label="Select District" id="district" name="district" required>
            <?php foreach ($district_list as $district_list_item): ?>
                <?php if($district_list_item['active'] == 'yes'):?>
                    <option value="<?php echo $district_list_item['id']?>"><?php echo $district_list_item['district']?></option>
                <?php endif?>
            <?php endforeach?>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
  <div class="row">
        <div class="col">
            <div class="h3 text-center">Customer List</div>
        </div>
    </div>
  <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Title</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Middle Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Contact Number</th>
                        <th scope="col">District</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($customer_list as $customer_list_item):?>
                    <tr>
                        <td><?php echo $customer_list_item['id']?></td>
                        <td><?php echo $customer_list_item['title']?></td>
                        <td><?php echo $customer_list_item['first_name']?></td>
                        <td><?php echo $customer_list_item['middle_name']?></td>
                        <td><?php echo $customer_list_item['last_name']?></td>
                        <td><?php echo $customer_list_item['contact_no']?></td>
                        <td><?php echo $customer_list_item['district']?></td>   
                    </tr>
                    <?php endforeach?>
                    </tbody>
                </table>
                </div>
        </div>
    </div>
  </div>
</div>





