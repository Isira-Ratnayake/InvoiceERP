<?php
/**
 * Footer shared by all views of ad site.
 */
?>
</div>
  <!-- footer -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark custom-footer">
        <div class="container-fluid justify-content-center">
            <span class="navbar-text">Csquare Technologies Private Limited &copy; 2022</span>
        </div>
    </nav>
</body>
</html>