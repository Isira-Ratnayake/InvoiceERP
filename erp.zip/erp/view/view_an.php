<div class="container mt-5">
    <div class="row">
        <div class="col">
            <div class="h1 text-center"><?php echo $heading?></div>
        </div>
    </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form>
      <div class="h3 text-center">Select Report</div>
        <div class="form-group">
          <label for="reporttype">Report Type:</label>
          <select class="form-select" aria-label="Select Title" id="reporttype" name="reportype" onchange="visibilityControl();" required>
                <option value="1">Invoice Report</option>
                <option value="2">Invoice Item Report</option>
                <option value="3">Item Report</option>
            </select>
        </div>
      </form>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form id="invoicef" action="./index.php?action=handle_an_invoicef" method="POST">
        <div class="form-group">
            <label for="sdate">Start Date:</label>
            <input type="date" class="form-control" id="sdate" name="sdate" required>
          </div>
          <div class="form-group">
            <label for="edate">End Date:</label>
            <input type="date" class="form-control" id="edate" name="edate" required>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form id="invoiceitemf" class="hidden" action="./index.php?action=handle_an_invoiceitemf" method="POST">
        <div class="form-group">
            <label for="sdate">Start Date:</label>
            <input type="date" class="form-control" id="sdate" name="sdate" required>
          </div>
          <div class="form-group">
            <label for="edate">End Date:</label>
            <input type="date" class="form-control" id="edate" name="edate" required>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form id="itemf" class="hidden" action="./index.php?action=handle_an_itemf" method="POST">
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>

  <?php if($report_type == 'invoicef'):?>
  <div class="row">
        <div class="col">
            <div class="h3 text-center">Invoice Report</div>
            <div class="lead text-center"><?php echo $start_date . ' to ' . $end_date?></div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                    <tr>
                        <th scope="col">Invoice Number</th>
                        <th scope="col">Date &amp; Time</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Customer District</th>
                        <th scope="col">Item Count</th>
                        <th scope="col">Amount(Rs)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($report_dataset as $report_dataset_item):?>
                    <tr>
                        <td><?php echo $report_dataset_item['invoice_no']?></td>
                        <td><?php echo $report_dataset_item['date_time']?></td>
                        <td><?php echo $report_dataset_item['customer_name']?></td>
                        <td><?php echo $report_dataset_item['district']?></td>
                        <td><?php echo $report_dataset_item['item_count']?></td>
                        <td><?php echo $report_dataset_item['amount']?></td>
                    </tr>
                    <?php endforeach?>
                    </tbody>
                </table>
                </div>
        </div>
    </div>
<?php endif?>

<?php if($report_type == 'invoiceitemf'):?>
  <div class="row">
        <div class="col">
            <div class="h3 text-center">Invoice Item Report</div>
            <div class="lead text-center"><?php echo $start_date . ' to ' . $end_date?></div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                    <tr>
                        <th scope="col">Invoice Number</th>
                        <th scope="col">Date &amp; Time</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Item Code</th>
                        <th scope="col">Item Name</th>
                        <th scope="col">Item Category</th>
                        <th scope="col">Item Subcategory</th>
                        <th scope="col">Unit Price</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($report_dataset as $report_dataset_item):?>
                    <tr>
                        <td><?php echo $report_dataset_item['invoice_no']?></td>
                        <td><?php echo $report_dataset_item['date_time']?></td>
                        <td><?php echo $report_dataset_item['customer_name']?></td>
                        <td><?php echo $report_dataset_item['item_code']?></td>
                        <td><?php echo $report_dataset_item['item_name']?></td>
                        <td><?php echo $report_dataset_item['category']?></td>
                        <td><?php echo $report_dataset_item['sub_category']?></td>
                        <td><?php echo $report_dataset_item['unit_price']?></td>
                    </tr>
                    <?php endforeach?>
                    </tbody>
                </table>
                </div>
        </div>
    </div>
<?php endif?>

<?php if($report_type == 'itemf'):?>
  <div class="row">
        <div class="col">
            <div class="h3 text-center">Item Report</div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                    <tr>
                        <th scope="col">Item Name</th>
                        <th scope="col">Item Code</th>
                        <th scope="col">Item Category</th>
                        <th scope="col">Item Subcategory</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Unit Price</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($report_dataset as $report_dataset_item):?>
                    <tr>
                        <td><?php echo $report_dataset_item['item_name']?></td>
                        <td><?php echo $report_dataset_item['item_code']?></td>
                        <td><?php echo $report_dataset_item['category']?></td>
                        <td><?php echo $report_dataset_item['sub_category']?></td>
                        <td><?php echo $report_dataset_item['quantity']?></td>
                        <td><?php echo $report_dataset_item['unit_price']?></td>
                    </tr>
                    <?php endforeach?>
                    </tbody>
                </table>
                </div>
        </div>
    </div>
<?php endif?>
</div>

<script>
  let reporttype_select = document.getElementById("reporttype");
  let itemf = document.getElementById("itemf");
  let invoiceitemf = document.getElementById("invoiceitemf");
  let invoicef = document.getElementById("invoicef");

  function visibilityControl() {
    let value = reporttype_select.value;
    if(value == 1) {
      invoicef.classList.remove("hidden");
      invoiceitemf.classList.add("hidden");
      itemf.classList.add("hidden");
    }
    else if(value == 2) {
      invoiceitemf.classList.remove("hidden");
      invoicef.classList.add("hidden");
      itemf.classList.add("hidden"); 
    }
    else {
      invoicef.classList.add("hidden");
      invoiceitemf.classList.add("hidden");
      itemf.classList.remove("hidden");
    }
  }
</script>