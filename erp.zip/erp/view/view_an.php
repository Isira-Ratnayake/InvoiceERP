<div class="container mt-5">
    <div class="row">
        <div class="col">
            <div class="h1 text-center"><?php echo $heading?></div>
        </div>
    </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form>
      <div class="h3 text-center">Select Report</div>
        <div class="form-group">
          <label for="reporttype">Report Type:</label>
          <select class="form-select" aria-label="Select Title" id="reporttype" name="reportype" onchange="visibilityControl();" required>
                <option value="1">Invoice Report</option>
                <option value="2">Invoice Item Report</option>
                <option value="3">Item Report</option>
            </select>
        </div>
      </form>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form id="invoicef" action="./index.php?action=handle_im_register" method="POST">
        <div class="form-group">
            <label for="sdate">Start Date:</label>
            <input type="date" class="form-control" id="sdate" name="sdate" required>
          </div>
          <div class="form-group">
            <label for="edate">End Date:</label>
            <input type="date" class="form-control" id="edate" name="edate" required>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form id="invoiceitemf" class="hidden" action="./index.php?action=handle_im_register" method="POST">
        <div class="form-group">
            <label for="sdate">Start Date:</label>
            <input type="date" class="form-control" id="sdate" name="sdate" required>
          </div>
          <div class="form-group">
            <label for="edate">End Date:</label>
            <input type="date" class="form-control" id="edate" name="edate" required>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form id="itemf" class="hidden" action="./index.php?action=handle_im_register" method="POST">
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
  <div class="row">
        <div class="col">
            <div id="r-heading" class="h3 text-center"></div>
        </div>
    </div>
</div>

<script>
  let reporttype_select = document.getElementById("reporttype");
  let itemf = document.getElementById("itemf");
  let invoiceitemf = document.getElementById("invoiceitemf");
  let invoicef = document.getElementById("invoicef");

  function visibilityControl() {
    let value = reporttype_select.value;
    if(value == 1) {
      invoicef.classList.remove("hidden");
      invoiceitemf.classList.add("hidden");
      itemf.classList.add("hidden");
    }
    else if(value == 2) {
      invoiceitemf.classList.remove("hidden");
      invoicef.classList.add("hidden");
      itemf.classList.add("hidden"); 
    }
    else {
      invoicef.classList.add("hidden");
      invoiceitemf.classList.add("hidden");
      itemf.classList.remove("hidden");
    }
  }
</script>