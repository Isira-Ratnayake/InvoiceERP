<div class="container mt-5">
    <div class="row">
        <div class="col">
            <div class="h1 text-center"><?php echo $heading?></div>
        </div>
    </div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <form action="./index.php?action=handle_im_register" method="POST">
      <div class="h3 text-center">Register Item</div>
        <div class="form-group">
          <label for="icode">Item Code:</label>
          <input type="text" class="form-control" id="icode" name="icode" required>
        </div>
        <div class="form-group">
          <label for="iname">Item Name:</label>
          <input type="text" class="form-control" id="iname" name="iname" required>
        </div>
        <div class="form-group">
          <label for="icat">Item Category:</label>
          <select class="form-select" aria-label="Select Item Category" id="icat" name="icat" required>
            <?php foreach ($category_list as $category_list_item): ?>
              <option value="<?php echo $category_list_item['id']?>"><?php echo $category_list_item['category']?></option>
            <?php endforeach?>
          </select>
        </div>
        <div class="form-group">
          <label for="isubcat">Item Sub Category:</label>
          <select class="form-select" aria-label="Select Item Category" id="isubcat" name="isubcat" required>
            <?php foreach ($subcategory_list as $subcategory_list_item): ?>
              <option value="<?php echo $subcategory_list_item['id']?>"><?php echo $subcategory_list_item['sub_category']?></option>
            <?php endforeach?>
          </select>
        </div>
        <div class="form-group">
          <label for="qty">Quantity:</label>
          <input type="number" class="form-control" min="0" step="1" id="qty" name="qty" value="0" required>
        </div>
        <div class="form-group">
          <label for="uprice">Unit Price:</label>
          <input type="number" class="form-control" min="0.00" step=".01" id="uprice" name="uprice" value="0.00" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
  <div class="row">
        <div class="col">
            <div class="h3 text-center">Item List</div>
        </div>
    </div>
  <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Item Code</th>
                        <th scope="col">Item Name</th>
                        <th scope="col">Category</th>
                        <th scope="col">Subcategory</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Unit Price</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($item_list as $item_list_item):?>
                    <tr>
                        <td><?php echo $item_list_item['id']?></td>
                        <td><?php echo $item_list_item['item_code']?></td>
                        <td><?php echo $item_list_item['item_name']?></td>
                        <td><?php echo $item_list_item['category']?></td>
                        <td><?php echo $item_list_item['sub_category']?></td>
                        <td><?php echo $item_list_item['quantity']?></td>
                        <td><?php echo $item_list_item['unit_price']?></td>   
                    </tr>
                    <?php endforeach?>
                    </tbody>
                </table>
                </div>
        </div>
    </div>
  </div>
</div>