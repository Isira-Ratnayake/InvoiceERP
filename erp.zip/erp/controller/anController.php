<?php
require_once('./data/dbConnection.php');

class AnController {

    private $dbConnection;

    public function __construct() {
        $this->dbConnection = new dbConnection();
        $this->dbConnection->connect();
    }

    public function prepare_page($report_type='none', $report_dataset=null, $start_date=null, $end_date=null) {
        $heading = 'Reports';
        $sector = 'an';
        include('./view/view_header.php');
        include('./view/view_an.php');
        include('./view/view_footer.php');
    }

    public function prepare_page_invoicef($start_date, $end_date) {
        if($this->validate_dates($start_date, $end_date)) {
            $invoicef_list = $this->get_invoicef_list($start_date, $end_date);
            $this->prepare_page('invoicef', $invoicef_list, $start_date, $end_date);
        }
        else {
            $this->prepare_page();
        }
    }

    private function get_invoicef_list($start_date, $end_date) {
        $query = <<<END
        select invoice.invoice_no, concat(invoice.date, ' ', invoice.time) as 'date_time', 
        concat(customer.title, ' ',customer.first_name,' ',customer.middle_name, ' ',customer.last_name) as 'customer_name', 
        district.district, invoice.item_count, invoice.amount from invoice
        inner join customer on invoice.customer = customer.id
        inner join district on customer.district = district.id
        where invoice.date >= :startdate and invoice.date <= :enddate;
        END;
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->bindValue(':startdate', $start_date);
            $statement->bindValue(':enddate', $end_date);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
            echo $e->getMessage();
        }
    }

    public function prepare_page_invoiceitemf($start_date, $end_date) {
        if($this->validate_dates($start_date, $end_date)) {
            
        }
        $invoiceitemf_list = $this->get_invoiceitemf_list($start_date, $end_date);
        $this->prepare_page('invoiceitemf', $invoiceitemf_list, $start_date, $end_date);
    }

    private function get_invoiceitemf_list($start_date, $end_date) {
        $query = <<<END
        select invoice_master.invoice_no, concat(invoice.date, ' ', invoice.time) as 'date_time',
        concat(customer.title, ' ',customer.first_name,' ',customer.middle_name, ' ',customer.last_name) as 'customer_name',
        item.item_code, item.item_name, item_category.category, item_subcategory.sub_category, item.unit_price from invoice_master
        inner join item on invoice_master.item_id = item.id
        inner join item_category on item.item_category = item_category.id
        inner join item_subcategory on item.item_subcategory = item_subcategory.id
        inner join invoice on invoice_master.invoice_no = invoice.invoice_no
        inner join customer on invoice.customer = customer.id
        where invoice.date >= :startdate and invoice.date <= :enddate;
        END;
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->bindValue(':startdate', $start_date);
            $statement->bindValue(':enddate', $end_date);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
            echo $e->getMessage();
        }
    }

    public function prepare_page_itemf() {
        $itemf_list = $this->get_itemf_list();
        $this->prepare_page('itemf', $itemf_list);
    }

    private function get_itemf_list() {
        $query = <<<END
        select DISTINCT(item.item_name), item.item_code, item_category.category,
        item_subcategory.sub_category, item.quantity, item.unit_price from item
        inner join item_category on item.item_category = item_category.id
        inner join item_subcategory on item.item_subcategory = item_subcategory.id;
        END;
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
            echo $e->getMessage();
        }
    }

    private function validate_dates($start_date, $end_date) {
        $is_valid = true;
        if(empty($start_date)) {
            $is_valid = false;
        }
        if(empty($end_date)) {
            $is_valid = false;
        }
        $start_date_obj = new DateTime($start_date);
        $end_date_obj = new DateTime($end_date);
        $interval = $start_date_obj->diff($end_date_obj);
        if($interval->format('%R') == '-') {
            $is_valid = false;
        }
        return $is_valid;
    }
}

?>