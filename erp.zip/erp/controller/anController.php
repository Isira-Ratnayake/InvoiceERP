<?php
require_once('./data/dbConnection.php');

class AnController {

    private $dbConnection;

    public function __construct() {
        $this->dbConnection = new dbConnection();
        $this->dbConnection->connect();
    }

    public function prepare_page() {
        $heading = 'Reports';
        $sector = 'an';
        include('./view/view_header.php');
        include('./view/view_an.php');
        include('./view/view_footer.php');
    }
}

?>