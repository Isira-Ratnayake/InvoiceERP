<?php
require_once('./data/dbConnection.php');

class ImController {

    private $dbConnection;

    public function __construct() {
        $this->dbConnection = new dbConnection();
        $this->dbConnection->connect();
    }

    public function prepare_page() {
        $heading = 'Item Management';
        $sector = 'im';
        $category_list = $this->get_category_list();
        $subcategory_list = $this->get_subcategory_list();
        $item_list = $this->get_item_list();
        include('./view/view_header.php');
        include('./view/view_im.php');
        include('./view/view_footer.php');
    }

    public function register_item($item) {
        if($this->validate_item($item)) {
            $this->insert_item_record($item);
        }
        header('location:./index.php?action=im');
    }

    private function get_category_list() {
        $query = 'select * from item_category';
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
        }
    }

    private function get_subcategory_list() {
        $query = 'select * from item_subcategory';
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
        }
    }

    private function insert_item_record($item) {
        $query = 'insert into item (item_code, item_category, item_subcategory, item_name, quantity, unit_price) values (:item_code, :item_category, :item_subcategory, :item_name, :quantity, :unit_price);';
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->bindValue(':item_code', $item->get_item_code());
            $statement->bindValue(':item_category', $item->get_item_category());
            $statement->bindValue(':item_subcategory', $item->get_item_subcategory());
            $statement->bindValue(':item_name', $item->get_item_name());
            $statement->bindValue(':quantity', $item->get_quantity());
            $statement->bindValue(':unit_price', $item->get_unit_price());
            $statement->execute();
            $statement->closeCursor();
        }
        catch(Exception $e) {
            //Error Handling
            echo $e->getMessage();
        }       
    }

    private function get_item_list() {
        $query = 'select item.id, item.item_code, item.item_name, item.quantity, item.unit_price, item_category.category, item_subcategory.sub_category from item inner join item_category on item.item_category = item_category.id inner join item_subcategory on item.item_subcategory = item_subcategory.id;';
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
        }        
    }

    private function validate_item($item) {
        $is_valid = true;
        if(empty($item->get_item_code())) {
            $is_valid = false;
        }
        if(empty($item->get_item_category())) {
            $is_valid = false;
        }
        if(empty($item->get_item_subcategory())) {
            $is_valid = false;
        }
        if(empty($item->get_item_name())) {
            $is_valid = false;
        }
        if(empty($item->get_quantity())) {
            $is_valid = false;
        }
        if(empty($item->get_unit_price())) {
            $is_valid = false;
        }
        return $is_valid;
    }
}

?>