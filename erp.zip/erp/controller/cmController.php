<?php
require_once('./data/dbConnection.php');

class CmController {

    private $dbConnection;

    public function __construct() {
        $this->dbConnection = new dbConnection();
        $this->dbConnection->connect();
    }

    public function prepare_page() {
        $heading = 'Customer Management';
        $sector = 'cm';
        $district_list = $this->get_district_list();
        $customer_list = $this->get_customer_list();
        include('./view/view_header.php');
        include('./view/view_cm.php');
        include('./view/view_footer.php');
    }

    public function register_customer($customer) {
        if($this->validate_customer($customer)) {
            $this->insert_customer_record($customer);
        }
        header('location:./index.php?action=cm');
    }

    private function insert_customer_record($customer) {
        $query = 'insert into customer (title, first_name, middle_name, last_name, contact_no, district) values (:title, :first_name, :middle_name, :last_name, :contact_no, :district);';
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->bindValue(':title', $customer->get_title());
            $statement->bindValue(':first_name', $customer->get_first_name());
            $statement->bindValue(':middle_name', $customer->get_middle_name());
            $statement->bindValue(':last_name', $customer->get_last_name());
            $statement->bindValue(':contact_no', $customer->get_contact_no());
            $statement->bindValue(':district', $customer->get_district());
            $statement->execute();
            $statement->closeCursor();
        }
        catch(Exception $e) {
            //Error Handling
            echo $e->getMessage();
        }
    }

    private function get_district_list() {
        $query = 'select * from district';
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
        }
    }

    private function get_customer_list() {
        $query = 'select customer.id, customer.title, customer.first_name, customer.middle_name, customer.last_name, customer.contact_no, district.district from customer inner join district where customer.district = district.id;';
        try {
            $statement = $this->dbConnection->get_pdo()->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll();
            $statement->closeCursor();
            return $result;
        }
        catch(Exception $e) {
            //Error Handling
        }
    }

    private function validate_customer($customer) {
        $is_valid = true;
        if(empty($customer->get_title())) {
            $is_valid = false;
        }
        if(empty($customer->get_first_name())) {
            $is_valid = false;
        }
        if(empty($customer->get_middle_name())) {
            $is_valid = false;
        }
        if(empty($customer->get_last_name())) {
            $is_valid = false;
        }
        if(empty($customer->get_contact_no())) {
            $is_valid = false;
        }
        if(empty($customer->get_district())) {
            $is_valid = false;
        }
        return $is_valid;
    }
}

?>