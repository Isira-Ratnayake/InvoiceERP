<?php

class dbConnection {
    private $pdo;
    private $dsn = 'mysql:host=localhost;dbname=erpdb';
    private $username = 'root';
    private $password = '';
    private $options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

    public function connect() {
        try {
            $this->pdo = new PDO($this->dsn, $this->username, $this->password, $this->options);
        }
        catch(PDOException $e) {
            //Error handling
            echo $e->getMessage();
        }
    }

    public function get_pdo() {
        return $this->pdo;
    }
}




?>