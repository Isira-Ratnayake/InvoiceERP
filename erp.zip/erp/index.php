<?php
    /**
     * Import Controllers
     */
    require_once('./controller/cmController.php');
    require_once('./controller/imController.php');
    require_once('./controller/anController.php');
    require_once('./model/customer.php');
    require_once('./model/item.php');
    require_once('./data/dbConnection.php');

    /* Initialise the action parameter */
    $action = filter_input(INPUT_POST, 'action');       //Check $_POST
    if($action === null) {
        $action = filter_input(INPUT_GET, 'action');    //Check $_GET
        if($action === null) {
            $action = 'cm';                          //set default value if $action is unspecified
        }
    }

     /* Switch statement to control website based on $action */
    switch($action) {
        /* Customer Management */
        case 'cm':
            $cm = new CmController();
            $cm->prepare_page();
            break;

        case 'handle_cm_register':
            $customer = new Customer(-1, $_POST['title'], $_POST['fname'], $_POST['mname'], $_POST['lname'], $_POST['cno'], $_POST['district']);
            $cm = new CmController();
            $cm->register_customer($customer);
            break;

        case 'im':
            $im = new ImController();
            $im->prepare_page();
            break;
        
        case 'handle_im_register':
            $item = new Item(-1, $_POST['icode'], $_POST['icat'], $_POST['isubcat'], $_POST['iname'], $_POST['qty'], $_POST['uprice']);
            $im = new ImController();
            $im->register_item($item);
            break;
        
        case 'an':
            $an = new AnController();
            $an->prepare_page();
            break;

        default:
            header('location:./?action=cm');
            break;
    }