<?php
    /**
     * Import Controllers
     */
    require_once('./controller/cmController.php');
    require_once('./controller/imController.php');
    require_once('./controller/anController.php');
    require_once('./model/customer.php');
    require_once('./model/item.php');
    require_once('./data/dbConnection.php');

    /* Initialise the action parameter */
    $action = filter_input(INPUT_POST, 'action');       //Check $_POST
    if($action === null) {
        $action = filter_input(INPUT_GET, 'action');    //Check $_GET
        if($action === null) {
            $action = 'cm';                          //set default value if $action is unspecified
        }
    }

     /* Switch statement to control website based on $action */
    switch($action) {
        /* Customer Management */
        case 'cm':
            $cm = new CmController();
            $cm->prepare_page();
            break;

        case 'handle_cm_register':
            $customer = new Customer(-1, getValueFromPost('title'), getValueFromPost('fname'), getValueFromPost('mname'), getValueFromPost('lname'), getValueFromPost('cno'), getValueFromPost('district'));
            $cm = new CmController();
            $cm->register_customer($customer);
            break;

        /* Item Management */
        case 'im':
            $im = new ImController();
            $im->prepare_page();
            break;
        
        case 'handle_im_register':
            $item = new Item(-1, getValueFromPost('icode'), getValueFromPost('icat'), getValueFromPost('isubcat'), getValueFromPost('iname'), getValueFromPost('qty'), getValueFromPost('uprice'));
            $im = new ImController();
            $im->register_item($item);
            break;
        
        /* Report Generation */
        case 'an':
            $an = new AnController();
            $an->prepare_page();
            break;
        
        case 'handle_an_invoicef':
            $an = new AnController();
            $an->prepare_page_invoicef(getValueFromPost('sdate'), getValueFromPost('edate'));
            break;

        case 'handle_an_invoiceitemf':
            $an = new AnController();
            $an->prepare_page_invoiceitemf(getValueFromPost('sdate'), getValueFromPost('edate'));
            break;

        case 'handle_an_itemf':
            $an = new AnController();
            $an->prepare_page_itemf();
            break;
        
        /* Bad action value handling */
        default:
            header('location:./?action=cm');
            break;
    }

function getValueFromPost(string $key)
{
   return isset($_POST[$key]) ? $_POST[$key] : null;
}

